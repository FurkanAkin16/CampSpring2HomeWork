package kodlama.io.Programming.Languages;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProgrammingLanguagesApplicationTests {

	@Test
	void contextLoads() {
	}

}
